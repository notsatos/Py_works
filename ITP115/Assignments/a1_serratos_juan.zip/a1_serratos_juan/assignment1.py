
   # Juan Serratos, jserrato@usc.edu
   # ITP 115, Fall 2022
   # Section: 31865
   # Assignment 1
   # Description: This programs prints certain statements about myself such as
   # my name, some false and true facts about myself which assign corresponding truth values to them, and
   # some things about my pets & siblings. 
def main ():
   first = 'Juan'
   last = 'Serratos'

#Defining strings to statement sentences 
   statement1 = "I'm a third year student from California."
   statement2 = "I eat banana cream pie at every one of my birthdays."
   statement3 = "I do not like banana cream pie"

#Assigning true values to the previously assigned sentences
   true1 = True
   true2 = False
   true3 = True

#Assigning integer values to the number of pets and siblings I have, respectively. 
   pets = 1
   siblings = 2 

   print("Full Name:", first, last)
   print("Number of Pets:", pets )
   print("Number of Siblings:", siblings )
   print("Statement 1:", statement1)
   print("Statement 2:", statement2)
   print("Statement 3:", statement3)

   print("Statment 1 is", true1)
   print("Statment 2 is", true2)
   print("Statment 3 is", true3)
main()

